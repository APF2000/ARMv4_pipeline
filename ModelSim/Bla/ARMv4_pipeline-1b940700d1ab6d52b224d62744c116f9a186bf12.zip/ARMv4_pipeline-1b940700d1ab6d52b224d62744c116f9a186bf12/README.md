# ARMv4_pipeline
Uma implementação da versão pipeline do processador ARM, conforme descrito no livro da disiplina : https://books.google.com.br/books/about/Organiza%C3%A7%C3%A3o_e_projeto_de_computadores.html?id=3YaCBAAACAAJ&amp;source=kp_book_description&amp;redir_esc=y
